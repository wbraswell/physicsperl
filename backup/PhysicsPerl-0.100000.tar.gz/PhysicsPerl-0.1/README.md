physicsperl
===========

High-Performance Physics Algorithms &amp; Applications In RPerl
